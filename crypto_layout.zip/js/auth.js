document.getElementById("login_switcher").onclick = switch_to_sign_up
function switch_to_sign_up() {
    console.log('sign_up')
}

document.getElementById("login_switcher").onclick = switch_to_log_in
function switch_to_log_in() {
    console.log('login')
}

function switch_to_code() {
    console.log('code')
}